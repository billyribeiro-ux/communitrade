# Notices for Jakarta Contexts and Dependency Injection

This content is produced and maintained by the Jakarta Contexts and Dependency Injection
project.

* Project home: https://projects.eclipse.org/projects/ee4j.cdi

## Trademarks

Jakarta Contexts and Dependency Injection is a trademark of the Eclipse Foundation.

## Copyright

All content is the property of the respective authors or their employers. For
more information regarding authorship of content, please consult the listed
source code repository logs.

## Declared Project Licenses

This program and the accompanying materials are made available under the terms
of the Apache License v. 2.0 which is available at
http://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0

## Source Code

The project maintains the following source code repositories:

* https://github.com/jakartaee/cdi
* https://github.com/jakartaee/cdi-tck
* https://github.com/jakartaee/inject
* https://github.com/jakartaee/inject-spec
* https://github.com/jakartaee/inject-tck

The project also maintains the following legacy CPL licensed source code repositories:

* https://github.com/eclipse-ee4j/cdi-cpl
* https://github.com/eclipse-ee4j/cdi-tck-cpl

## Third-party Content

## Cryptography

Content may contain encryption software. The country in which you are currently
may have restrictions on the import, possession, and use, and/or re-export to
another country, of encryption software. BEFORE using any encryption software,
please check the country's laws, regulations and policies concerning the import,
possession, or use, and re-export of encryption software, to see if this is
permitted.
